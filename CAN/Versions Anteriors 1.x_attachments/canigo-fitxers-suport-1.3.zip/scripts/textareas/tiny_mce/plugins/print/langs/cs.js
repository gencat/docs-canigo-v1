/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2006/11/21 07:32:43 mmateos Exp $ 
 */  

tinyMCE.addToLang('',{
print_desc : 'Tisk'
});

