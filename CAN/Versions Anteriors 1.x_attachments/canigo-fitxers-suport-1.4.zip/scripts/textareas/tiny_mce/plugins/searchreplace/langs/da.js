// DK lang variables contributed by Jan Moelgaard

tinyMCE.addToLang('',{
searchreplace_search_desc : 'S&#248;g',
searchreplace_searchnext_desc : 'S&#248;g igen',
searchreplace_replace_desc : 'S&#248;g og erstat',
searchreplace_notfound : 'S&#248;gningen er f&#230;rdig. S&#248;geudtrykket kunne ikke findes.',
searchreplace_search_title : 'S&#248;g',
searchreplace_replace_title : 'S&#248;g og erstat',
searchreplace_allreplaced : 'Alle forekomster af s&#248;geudtrykket blev erstattet.',
searchreplace_findwhat : 'Hvad skal vi s&#248;ge efter',
searchreplace_replacewith : 'Erstat det med',
searchreplace_direction : 'Retning',
searchreplace_up : 'Op',
searchreplace_down : 'Ned',
searchreplace_case : 'Skelne mellem store og sm&#229; bogstaver',
searchreplace_findnext : 'S&#248;g efter&nbsp;n&#230;ste',
searchreplace_replace : 'Erstat',
searchreplace_replaceall : 'Erstat&nbsp;alle',
searchreplace_cancel : 'Fortryd'
});
