// SE lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Generella inst&auml;llningar',
tab_appearance : 'Visuella inst&auml;llningar',
tab_advanced : 'Avancerade inst&auml;llningar',
general : 'Generella',
title : 'Titel',
preview : 'F&ouml;rhandsgranskning',
constrain_proportions : 'Beh&aring;ll proportionerna',
langdir : 'Skrift riktning',
langcode : 'Spr&aring;k k&aring;d',
long_desc : 'Long beskrivning',
style : 'Stil',
classes : 'CSS Classer',
ltr : 'V&auml;nster till h&ouml;ger',
rtl : 'H&ouml;ger till v&auml;nster',
id : 'Id',
image_map : 'Bild karta',
swap_image : 'Byt bild',
alt_image : 'Alternativ bild',
mouseover : 'n&auml;r pekaren &auml;r &ouml;ver',
mouseout : 'n&auml;r pekaren &auml;r utanf&ouml;r',
misc : '&Ouml;vrigt',
example_img : 'F&ouml;rhandsgransknings bild',
missing_alt : '&Auml;r du s&auml;ker p&aring; att du vill forts&auml;tta utan att skriva en bild beskrivning. Utan en alternativ beskrivning &auml;r bilden inte handikapanpassad.'
});
