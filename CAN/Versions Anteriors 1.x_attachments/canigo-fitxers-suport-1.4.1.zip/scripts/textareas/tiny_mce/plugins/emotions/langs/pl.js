// PL lang variables

tinyMCE.addToLang('',{
insert_emotions_title : 'Wstaw emtoikone',
emotions_desc : 'Emtoikony'
});
