// UK lang variables

tinyMCE.addToLang('',{
iespell_desc : 'Dechrau gwirio sillafu',
iespell_download : "Methwyd canfod ieSpell. Cliciwch OK i fynd i'r dudalen lawrlwytho."
});

