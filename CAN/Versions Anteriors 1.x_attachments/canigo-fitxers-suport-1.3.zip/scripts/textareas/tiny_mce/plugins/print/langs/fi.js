// FI lang variables by Tuomo Aura, Ateco.fi

tinyMCE.addToLang('',{
print_desc : 'Tulosta'
});
