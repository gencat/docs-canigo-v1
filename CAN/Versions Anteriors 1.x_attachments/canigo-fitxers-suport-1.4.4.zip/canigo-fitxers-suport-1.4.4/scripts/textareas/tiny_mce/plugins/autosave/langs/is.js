// Iceland lang variables by Johannes Birgir Jensson

tinyMCE.addToLang('',{
autosave_unload_msg : 'Breytingarnar sem �� ger�ir munu hverfa ef �� flakkar anna�.'
});
