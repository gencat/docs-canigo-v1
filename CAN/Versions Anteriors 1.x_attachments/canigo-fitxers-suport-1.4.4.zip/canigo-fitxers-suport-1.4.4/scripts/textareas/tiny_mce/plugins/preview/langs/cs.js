/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2010/04/12 14:44:13 cvs Exp $ 
 */  

tinyMCE.addToLang('',{
preview_desc : 'Náhled'
});

