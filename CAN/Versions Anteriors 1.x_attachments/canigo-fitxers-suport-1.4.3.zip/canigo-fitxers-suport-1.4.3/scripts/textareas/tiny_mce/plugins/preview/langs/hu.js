// HU lang variables

tinyMCE.addToLang('',{
preview_desc : 'El�n�zet'
});
