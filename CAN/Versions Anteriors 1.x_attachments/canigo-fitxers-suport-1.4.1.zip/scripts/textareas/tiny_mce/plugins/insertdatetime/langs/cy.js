// UK lang variables

tinyMCE.addToLang('',{
insertdate_def_fmt : '%Y-%m-%d',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'Mewnosod dyddiad',
inserttime_desc : 'Mewnosod amser',
inserttime_months_long : new Array("Ionawr", "Chwefror", "Mawrth", "Ebrill", "Mai", "Mehefin", "Gorffennaf", "Awst", "Medi", "Hydref", "Tachwedd", "Rhagfyr"),
inserttime_months_short : new Array("Ion", "Chwe", "Maw", "Ebr", "Mai", "Meh", "Gor", "Aws", "Med", "Hyd", "Tach", "Rhag"),
inserttime_day_long : new Array("Dydd Sul", "Dydd Llun", "Dydd Mawrth", "Dydd Mercher", "Dydd Iau", "Dydd Gwener", "Dydd Sadwrn", "Dydd Sul"),
inserttime_day_short : new Array("Sul", "Llun", "Maw", "Mer", "Iau", "Gwe", "Sad", "Sul")
});
