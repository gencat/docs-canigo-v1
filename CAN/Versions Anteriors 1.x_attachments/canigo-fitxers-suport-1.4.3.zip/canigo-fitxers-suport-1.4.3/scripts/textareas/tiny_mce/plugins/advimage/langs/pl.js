// PL lang variables

tinyMCE.addToLang('',{
insert_image_alt2 : 'Tytu� obrazka',
insert_image_onmousemove : 'Obrazek zast�pczy',
insert_image_mouseover : 'po najechaniu myszy',
insert_image_mouseout : 'po odjechaniu myszy'
});
