// DK lang variables contributed by Jan Moelgaard

tinyMCE.addToLang('',{
insert_advhr_desc : 'Inds&#230;t / rediger horisontal bj&#230;lke',
insert_advhr_width : 'Bredde',
insert_advhr_size : 'H&#248;jde',
insert_advhr_noshade : 'Ingen skygge'
});
