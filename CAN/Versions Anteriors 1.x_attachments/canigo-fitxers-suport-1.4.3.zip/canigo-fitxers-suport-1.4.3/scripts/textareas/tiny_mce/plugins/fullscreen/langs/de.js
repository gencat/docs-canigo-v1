// DE lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Vollbild-Modus',
fullscreen_desc : 'Vollbild-Modus umschalten'
});
