// Espa�ol por matiasl-AR

tinyMCELang['lang_zoom_prefix'] = 'Aumento de Tama�o';