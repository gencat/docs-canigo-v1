// Iceland lang variables by Johannes Birgir Jensson

tinyMCE.addToLang('',{
iespell_desc : 'Stafsetningarp&uacute;ki',
iespell_download : "ieSpell ekki til sta�ar. Smelli� � OK til a� sj� ni�urhalss��u."
});

