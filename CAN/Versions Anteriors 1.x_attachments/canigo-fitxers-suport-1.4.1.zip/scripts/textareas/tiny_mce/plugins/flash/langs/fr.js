// French lang variables by Laurent Dran

tinyMCE.addToLang('',{
insert_flash : 'Ins&eacute;rer / &eacute;diter une animation Flash',
insert_flash_file : 'Fichier-Flash (.swf)',
insert_flash_size : 'Taille',
insert_flash_list : 'Fichiers Flash',
flash_props : 'Flash properties'
});
