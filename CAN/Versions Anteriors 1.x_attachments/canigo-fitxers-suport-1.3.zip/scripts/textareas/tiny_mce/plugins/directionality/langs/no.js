// NO lang variables by Knut B. Jacobsen

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Retning fra venstre mot h&oslash;re',
directionality_rtl_desc : 'Retning fra h&oslash;re mot venstre'
});
