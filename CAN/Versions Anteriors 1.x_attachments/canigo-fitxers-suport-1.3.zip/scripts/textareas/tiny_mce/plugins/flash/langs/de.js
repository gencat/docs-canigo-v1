// DE lang variables

tinyMCE.addToLang('flash',{
title : 'Flash-Datei einf&uuml;gen/bearbeiten',
desc : 'Flash-Datei einf&uuml;gen/bearbeiten',
file : 'Flash-Datei (.swf)',
size : 'Gr&ouml;&szlig;e',
list : 'Flash-Dateien',
props : 'Flash-Eigenschaften',
general : 'Allgemein'
});
