// DK lang variables contributed by Jan Moelgaard

tinyMCE.addToLang('',{
autosave_unload_msg : 'De &#230;ndringer, du har lavet, vil g&#229; tabt, hvis du lukker denne side.'
});
