// French lang variables by Laurent Dran

tinyMCE.addToLang('',{
iespell_desc : 'Executer le v&eacute;rificateur d\'orthographe',
iespell_download : "ieSpell n\'a pas &eacute;t&eacute; trouv&eacute;. Cliquez sur OK pour aller au site de t&eacute;l&eacute;chargement."
});
