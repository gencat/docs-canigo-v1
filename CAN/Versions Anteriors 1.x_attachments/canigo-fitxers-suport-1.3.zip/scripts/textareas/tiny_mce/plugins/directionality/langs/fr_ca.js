// fr_ca lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Direction de la gauche vers la droite',
directionality_rtl_desc : 'Direction de la droite vers la gauche'
});
