// Greek lang variables by Jacaranda Bill

tinyMCE.addToLang('',{
insertdate_def_fmt : '%Y-%m-%d',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : '&Aring;������� ��&aring;��������',
inserttime_desc : '&Aring;������� ����',
inserttime_months_long : new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"),
inserttime_months_short : new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"),
inserttime_day_long : new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"),
inserttime_day_short : new Array("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
});
