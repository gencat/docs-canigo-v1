
var OpenFrameSelectFieldTag = {
  Version: '1.0'
}

function populateSelect(dataFromServer,dataFromBrowser) {

    // Obtain target from dataFromBrowser of previous call to callback
    var targetElem = $(dataFromBrowser['target']);
    var defaultSelected = dataFromBrowser['defaultSelected'];
    if (targetElem) {	
    	if (targetElem.options) {
    	    // reset target field    
	    	targetElem.options.length = 0;
	    }
	    targetElem.disabled = false;    
	    
	    if (dataFromServer) {
    		// grab list of options from list
    		var items = dataFromServer;
    		var itemsQuoted = new Array(items.length);
    		// Add a "'" to each value for presenting
		    for (var i=0; i<items.length; i++) {    		      
		      itemsQuoted[i] = new Object();
		      itemsQuoted[i]['label'] = "'" + items[i]['label'] + "'";
		      itemsQuoted[i]['value'] = "'" + items[i]['value'] + "'";
		      var label = items[i]['label'];
		      var value = items[i]['value'];
	  	      targetElem.options[i] = new Option(label, value);
	  	      if(value == defaultSelected){
	  	      	targetElem.options[i].selected = true;
	  	      }
    		}
	    	//DWRUtil.addOptions(targetElemId,dataFromServer,'label','value');
	    }
	    
    }    
}


/**
 * Extension of OpenFrameFieldTag
 */ 
OpenFrameSelectFieldTag.Base = function() {};
OpenFrameSelectFieldTag.Base.prototype = (new AjaxJspTag.Base()).extend({
});


/******************************************************************************
 * openFrame Select Dependency behaviour
 * Example of use  :
 * <script type="text/javascript">
 *   new OpenFrameSelectFieldTag.SelectTarget(
 *     {
 *           defaultSelected: "...", // defaultSelected
 *           source: "...", // id of source select
 * 			 target: "...", // id of target select
 *           paramName: "title" // name of parameter to be created in order to populate target
 *			 optionsSourceListName: "" // name of configured list name of target options
 *     });
 * </script>
 ******************************************************************************/
 

OpenFrameSelectFieldTag.SelectTarget = Class.create();
OpenFrameSelectFieldTag.SelectTarget.prototype=(new OpenFrameSelectFieldTag.Base()).extend({

  initialize: function(options) {
    this.setOptions(options);
    
    if (this.options.sourceElem) {    
    	this.attachBehaviors(this.options.sourceElem, this.options.eventType, this.actionElemChanged, this);
    	this.actionElemChanged(new Object());
	}
  },


  setOptions: function(options) {
	var sourceValue = new Array();
	sourceValue = options.source.split(",");
	var sourceParamName = new Array();
	sourceParamName = options.paramName.split(",");	  

	if (sourceValue.length > 1){
		for(var x = 0; x < sourceValue.length; x++){
			sourceValue[x] = $(sourceValue[x]);
			sourceParamName[x] = sourceParamName[x];
		}
	}else{
		sourceValue = $(options.source);
		sourceParamName = options.paramName; 
	}

   this.options = {
      defaultSelected: $(options.defaultSelected),
      sourceElem: sourceValue,
      targetElem: $(options.target),
      paramName: sourceParamName,
      optionsTargetListName: $(options.targetListName),
      eventType: options.eventType ? options.eventType : "change"
   }.extend(options || {});
   this.options.paramName = sourceParamName;
  },  

  
  actionElemChanged: function(e) {        
	  if(this.disabled){
		    if(this.disabled){
	    //	   new PeriodicalExecuterExt(this, this.checkLength,1);
	    	   return;
	    	}
	    }      
	      
	  	 this.selectParams={};
	    // Create parameters to call 'getOptions'
		this.selectParams.parametersCall = new Object();  	
		if (isArray(this.options.sourceElem)){
			for(var z= 0; z < this.options.sourceElem.length; z++)
		  	 	this.selectParams.parametersCall[this.options.paramName[z]] = $F(this.options.sourceElem[z]);  	
		}
		else
		  	 this.selectParams.parametersCall[this.options.paramName] = $F(this.options.sourceElem);
		 
		 Event.stop(e);
	  	 
	 	 this.selectParams.optionsListName = this.options.optionsTargetListName;
		 this.selectParams.dataFromBrowser = new Object();
	  	 this.selectParams.dataFromBrowser['target'] = this.options.targetElem.id;
	  	 this.selectParams.dataFromBrowser['defaultSelected'] = this.options.defaultSelected;
	 	 
		 this.selectParams.otherFormFields = this.getOtherFormFields(this.options.sourceElem);
		 
		 new PeriodicalExecuterExt(this, this.searchCallback,1);
		 
  	}, 
  	
  	putOtherOption: function (caller, dataFromServer) {
		if(dataFromServer && caller.options.otherKey) {		
			var otherOpt = new Object();
			otherOpt['label'] = caller.options.otherKey;
			otherOpt['value'] = caller.options.otherValue;
			dataFromServer.splice(0,0,otherOpt);
		}
	},
	
	getOtherFormFields: function(sourceElem) {
		var form = null;
		var inputs = null;
		var indexOfElem = null;
		for(var i=0; i<document.forms.length && form==null; i++) {
			var docForm = document.forms[i];
			var docInputs = Form.getElements(docForm);
			
			//can-268
			indexOfElem = -1;
			for(var count=0;count<docInputs.length;count++){
				if(docInputs[count].id==sourceElem.id){
					indexOfElem = count;
				}
			}
			//indexOfElem = docInputs.indexOf(sourceElem);
			//can-268 fi
			if(indexOfElem != -1) {
				form = docForm;
				inputs = docInputs;
			}
		}
		
		if(form == null) {
			return new Object();
		}
		else {
			inputs.splice(indexOfElem,1);
			var inputsList = new Object();
			for(var i=0; i<inputs.length; i++) {
				var input = inputs[i];
				var inputId = input.id;
				var inputValue = input.value;
				inputsList[inputId] = inputValue;
			}
			return inputsList;
		}
	},
	
	searchCallback:function(pe){
		pe.stop();
		var caller= pe.caller;
		webOptionsListService.getOptionsFromMap(
			caller.selectParams.optionsListName,
			caller.selectParams.parametersCall,
			caller.selectParams.otherFormFields,
			{
				callback:function(dataFromServer) {
					caller.putOtherOption(caller, dataFromServer);
					populateSelect(dataFromServer,caller.selectParams.dataFromBrowser);
					caller.disabled=null;
				},
				timeout:5000
			}
		);
	}
	
}); 
  	  
  	   
  	   

