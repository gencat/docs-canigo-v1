/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2006/11/20 20:27:25 mmateos Exp $ 
 */  

tinyMCE.addToLang('',{
insert_emotions_title : 'Vložit emotikonu',
emotions_desc : 'Emotikony'
});

