// DK lang variables contributed by Jan Moelgaard

tinyMCE.addToLang('',{
iespell_desc : 'Lav stavekontrol',
iespell_download : "ieSpell kan ikke findes. Klik p&#229; OK for at forts&#230;tte til downloadsiden."
});

