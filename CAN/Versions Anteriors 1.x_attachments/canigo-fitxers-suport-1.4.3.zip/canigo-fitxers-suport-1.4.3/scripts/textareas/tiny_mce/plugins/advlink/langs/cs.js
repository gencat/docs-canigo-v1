/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2010/04/12 14:44:06 cvs Exp $ 
 */  

tinyMCE.addToLang('',{
insert_link_target_same : 'Otevřít ve stejném okně/rámu',
insert_link_target_parent : 'Otevřít v rodičovském okně/rámu',
insert_link_target_top : 'Otevřít v nejvyšším rámu (přepíše všechny rámy)',
insert_link_target_blank : 'Otevřít v novém okně',
insert_link_target_named : 'Otevřít v okně',
insert_link_popup : 'JS-Popup',
insert_link_popup_url : 'Popup URL',
insert_link_popup_name : 'Název okna',
insert_link_popup_return : 'Vložit \'return false\'',
insert_link_popup_scrollbars : 'Ukázat posuvníky',
insert_link_popup_statusbar : 'Ukázat stavový řádek',
insert_link_popup_toolbar : 'Ukázat ovládací lištu',
insert_link_popup_menubar : 'Ukázat menu',
insert_link_popup_location : 'Ukázat lištu umístění',
insert_link_popup_resizable : 'Proměnná velikost okna',
insert_link_popup_size : 'Velikost',
insert_link_popup_position : 'Umístění (X/Y)',
insert_link_popup_missingtarget : 'Vložte název cíle nebo vyberte jinou volbu.'
});

