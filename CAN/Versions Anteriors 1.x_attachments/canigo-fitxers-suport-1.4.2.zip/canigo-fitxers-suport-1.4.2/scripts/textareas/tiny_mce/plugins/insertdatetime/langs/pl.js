// PL lang variables

tinyMCE.addToLang('',{
insertdate_def_fmt : '%Y-%m-%d',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'Wstaw aktualn� dat�',
inserttime_desc : 'Wstaw aktualny czas',
inserttime_months_long : new Array("Stycze�", "Luty", "Marzec", "Kwiecie�", "Maj", "Czerwiec", "Lipiec", "Sierpie�", "Wrzesien", "Pa�dziernik", "Listopad", "Grudzie�"),
inserttime_months_short : new Array("Stcz", "Lut", "Mar", "Kwi", "Maj", "Czer", "Lip", "Sier", "Wrze", "Pa�", "List", "Grudz"),
inserttime_day_long : new Array("Niedziela", "Poniedzia�ek", "Wtorek", "�roda", "Czwartek", "Pi�tek", "Sobota", "Niedziela"),
inserttime_day_short : new Array("Nie", "Pon", "Wto", "�ro", "Czw", "Pi�", "Sob", "Nie")
});
