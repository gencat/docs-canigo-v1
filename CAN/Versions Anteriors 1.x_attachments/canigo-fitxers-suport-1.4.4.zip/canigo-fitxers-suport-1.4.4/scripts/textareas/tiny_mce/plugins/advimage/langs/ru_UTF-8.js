// RU UTF-8 lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Основные',
tab_appearance : 'Визуализация',
tab_advanced : 'Расширенные',
general : 'Главные',
title : 'Заголовок',
preview : 'Предварительный просмотр',
constrain_proportions : 'Сохранить пропорции',
langdir : 'Описание языка',
langcode : 'Код языка',
long_desc : 'Полное описание',
style : 'Стили',
classes : 'Классы',
ltr : 'Слева направо',
rtl : 'Справа налево',
id : 'Id',
image_map : 'Карта изображения',
swap_image : 'Подмена картинки',
alt_image : 'Альтернативное изображение',
mouseover : 'при наведении мыши',
mouseout : 'когда уводите мышь',
misc : 'Прочее',
example_img : 'Визуализация&nbsp;расположения&nbsp;картинки'
});
