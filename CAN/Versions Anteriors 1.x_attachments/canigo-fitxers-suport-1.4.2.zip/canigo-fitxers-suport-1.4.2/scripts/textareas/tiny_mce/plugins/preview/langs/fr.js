// French lang variables by Laurent Dran

tinyMCE.addToLang('',{
preview_desc : 'Pr&eacute;visualisation'
});
