/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2006/11/20 20:21:36 mmateos Exp $ 
 */  

tinyMCE.addToLang('',{
autosave_unload_msg : 'Změny, které jste udělal(a) budou ztraceny, jestliže opustíte tuto stránku.'
});

