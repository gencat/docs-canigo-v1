// PL lang variables

tinyMCE.addToLang('',{
insert_link_target_same : 'Otw�rz w tym samym oknie',
insert_link_target_parent : 'Otw�rz w oknie rodzica / ramce',
insert_link_target_top : 'Otw�rz w g��wnym oknie (usuwa ramki)',
insert_link_target_blank : 'Otw�rz w nowym oknie',
insert_link_target_named : 'Otw�rz w oknie',
insert_link_popup : 'JS-Popup',
insert_link_popup_url : 'Popup URL',
insert_link_popup_name : 'Nazwa okna popup',
insert_link_popup_return : 'wstaw \'return false\'',
insert_link_popup_scrollbars : 'Poka� scrollbary',
insert_link_popup_statusbar : 'Poka� pasek statusu',
insert_link_popup_toolbar : 'Poka� paski narz�dzi',
insert_link_popup_menubar : 'Poka� pasek menu',
insert_link_popup_location : 'Poka� pasek adresy',
insert_link_popup_resizable : 'Stw�rz okno o zmiennych rozmiarach',
insert_link_popup_size : 'Rozmiar',
insert_link_popup_position : 'Pozycja (X/Y)',
insert_link_popup_missingtarget : 'Prosz� poda� nazw� dla celu lub wybra� inn� opcj�.',
insert_link_url : 'Adres URL',
insert_link_target : 'Cel'
});
