// DK lang variables contributed by Jan Moelgaard

tinyMCE.addToLang('emotions',{
title : 'Inds&#230;t smiley',
desc : 'Smileys',
cool : 'Cool',
cry : 'Gr&#229;d',
embarassed : 'Forlegen',
foot_in_mouth : 'Foden i munden',
frown : 'Rynket pande',
innocent : 'Uskyldig',
kiss : 'Kys',
laughing : 'Latter',
money_mouth : 'L&#230;kker mund',
sealed : 'Lukket af',
smile : 'Smil',
surprised : 'Overrasket',
tongue_out : 'R&#230;k tunge',
undecided : 'Usikker',
wink : 'Blink',
yell : 'R&#229;b'
});
