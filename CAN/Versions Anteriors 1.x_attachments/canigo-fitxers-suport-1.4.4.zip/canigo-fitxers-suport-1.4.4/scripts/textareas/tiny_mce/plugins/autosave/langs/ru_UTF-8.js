// RU lang variables UTF-8

tinyMCE.addToLang('',{
autosave_unload_msg : 'Изменения не будут потеряны если Вы уйдёте с этой страницы.'
});
