// HU lang variables

tinyMCE.addToLang('',{
save_desc : 'Ment�s'
});
