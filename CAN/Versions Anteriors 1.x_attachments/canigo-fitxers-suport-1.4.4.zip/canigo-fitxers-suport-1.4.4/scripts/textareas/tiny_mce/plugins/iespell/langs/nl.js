// NL lang variables

tinyMCE.addToLang('',{
iespell_desc : 'Spelling checker',
iespell_download : "ieSpell niet gedetecteerd. Klik OK om naar de download pagina te gaan."
});
