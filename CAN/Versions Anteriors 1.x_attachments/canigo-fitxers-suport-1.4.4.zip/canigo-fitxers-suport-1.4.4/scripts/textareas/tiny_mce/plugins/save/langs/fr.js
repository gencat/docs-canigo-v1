// French lang variables by Laurent Dran

tinyMCE.addToLang('',{
save_desc : 'Sauver'
});
